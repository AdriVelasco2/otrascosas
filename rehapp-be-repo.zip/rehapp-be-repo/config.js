require("dotenv").config();

const MONGODB_URI = process.env.MONGODB_URI;
// const MONGODB_URI = process.env.MONGODB_URI || "mongodb+srv://lucasmendezupintelligence:hXQ6tqgVlGEmU9n3@cluster0.nudsayk.mongodb.net/?retryWrites=true&w=majority";
const PORT = process.env.PORT || 4000;
const SECRET = process.env.SECRET_KEY;

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@localhost";
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "hXQ6tqgVlGEmU9n3";

module.exports = {MONGODB_URI, PORT, SECRET, ADMIN_EMAIL, ADMIN_USERNAME, ADMIN_PASSWORD}